import UIKit
import Photos

class EditPlatformViewController: UIViewController {
	
	
	@IBOutlet weak var titleLabel: UITextField!
	
	@IBOutlet weak var imageCover: UIImageView!
	var console: Console?
	
	@IBAction func btnTap(_ sender: Any) {
		
	}
	
	override func viewDidLoad() {
		super.viewDidLoad()
		if let console = console {
			setupFields()
		}
		// Do any additional setup after loading the view.
	}
	
	@IBAction func btnSav(_ sender: Any) {
		let console = console ?? Console(context: self.context)
		console.name = titleLabel.text ?? ""
		if let image = imageCover.image {
			console.image = image.pngData()
		}
		do {
			try self.context.save()
			self.navigationController?.popViewController(animated: true)
		} catch {
			print(error.localizedDescription)
		}
	}
	@IBAction func btnGetImage(_ sender: Any) {
		showAlert(with: console)
	}
	
}

extension EditPlatformViewController {
	
	// MARK: - Private methods
	
	private func setupFields() {
		titleLabel.text = console?.name
		if let image = console?.image {
			let imagem = UIImage(data: image)
			imageCover.image = imagem
		}
	}
	
	
	func showAlert(with console: Console?) {
				
		let alert = UIAlertController(title: "Selecionar capa", message: "De onde você quer escolher a capa?", preferredStyle: .actionSheet)
		
		let libraryAction = UIAlertAction(title: "Biblioteca de fotos", style: .default, handler: {(action: UIAlertAction) in
			self.selectPicture(sourceType: .photoLibrary)
		})
		alert.addAction(libraryAction)
		
		let photosAction = UIAlertAction(title: "Album de fotos", style: .default, handler: {(action: UIAlertAction) in
			self.selectPicture(sourceType: .savedPhotosAlbum)
		})
		alert.addAction(photosAction)
		
		let cancelAction = UIAlertAction(title: "Cancelar", style: .cancel, handler: nil)
		alert.addAction(cancelAction)
		
		alert.view.tintColor = UIColor(named: "second")
		
		present(alert, animated: true, completion: nil)
	}
	
	
	func chooseImageFromLibrary(sourceType: UIImagePickerController.SourceType) {
		
		DispatchQueue.main.async {
			let imagePicker = UIImagePickerController()
			imagePicker.sourceType = sourceType
			imagePicker.delegate = self
			imagePicker.allowsEditing = false
			imagePicker.navigationBar.tintColor = UIColor(named: "main")
			
			self.navigationController?.present(imagePicker, animated: true, completion: nil)
		}
		
	}
	
	func selectPicture(sourceType: UIImagePickerController.SourceType) {
		
		//Photos
		let photos = PHPhotoLibrary.authorizationStatus()
		if photos == .notDetermined {
			PHPhotoLibrary.requestAuthorization({status in
				if status == .authorized{
					
					self.chooseImageFromLibrary(sourceType: sourceType)
					
				} else {
					
					print("unauthorized -- TODO message")
				}
			})
		} else if photos == .authorized {
			
			self.chooseImageFromLibrary(sourceType: sourceType)
			
		} else if photos == .denied {
			print("mostrar uma alerta pro usuario pedindo para ele setar manualmente a permissao...")
		}
	}
	
}


extension EditPlatformViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
	
	// tip. implementando os 2 protocols o evento sera notificando apos user selecionar a imagem
	
	
	func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
		
	}
	
	func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
		
		if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
			
			// ImageView won't update with new image
			// bug fixed: https://stackoverflow.com/questions/42703795/imageview-wont-update-with-new-image
			DispatchQueue.main.async {
				self.imageCover.image = pickedImage
				
			}
			
		}
		
		dismiss(animated: true, completion: nil)
		
	}
	
}
