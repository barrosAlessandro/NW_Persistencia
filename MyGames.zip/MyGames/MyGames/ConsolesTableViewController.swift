//
//  ConsolesTableViewController.swift
//  MyGames
//
//  Created by Douglas Frari on 8/21/21.
//

import UIKit
import Photos

class ConsolesTableViewController: UITableViewController {
	
	var image: UIImage?
	var consoleused: Console?
	
    override func viewDidLoad() {
        super.viewDidLoad()

        loadConsoles()
    }
    
    func loadConsoles() {
        ConsolesManager.shared.loadConsoles(with: context)
        tableView.reloadData()
    }
	
	override func viewWillAppear(_ animated: Bool) {
		ConsolesManager.shared.loadConsoles(with: context)
		tableView.reloadData()
	}

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ConsolesManager.shared.consoles.count
    }
    
	@IBAction func btnAdd(_ sender: Any) {
		consoleused = nil
		self.performSegue(withIdentifier: "editPlatform", sender: self)
	}
	override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let console = ConsolesManager.shared.consoles[indexPath.row]
		if let image = console.image {
			let imagem = UIImage(data: image)
			cell.imageView?.image = imagem
		} else {
			cell.imageView?.image = nil
		}
        cell.textLabel?.text = console.name
        
        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    // DELEGATE que dispara a acao apos o click na celula
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let console = ConsolesManager.shared.consoles[indexPath.row]
		consoleused = console
		self.performSegue(withIdentifier: "editPlatform", sender: self)
        
        tableView.deselectRow(at: indexPath, animated: false)
    }
	
	override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
		 
		 // get a reference to the second view controller
		 let secondViewController = segue.destination as! EditPlatformViewController
		 
		 // set a variable in the second view controller with the data to pass
		secondViewController.console = consoleused
	 }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            ConsolesManager.shared.deleteConsole(index: indexPath.row, context: context)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
}
